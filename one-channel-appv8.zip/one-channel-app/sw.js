/* MILWAUKEE ONE-CHANNEL — service worker
   Cache-first for the app shell so the app launches with no network.
   Network-first for the model APIs, which must never be served stale. */

const VERSION = 'onechannel-v8';
const SHELL = [
  './',
  './index.html',
  './manifest.webmanifest',
  './icon-192.png',
  './icon-512.png',
  './icon-maskable-512.png',
  './apple-touch-icon.png',
  './favicon-32.png',
  './logo.png',
  './logo@2x.png'
];
// Third-party assets the app needs offline. Fetched opportunistically:
// if any single one fails the install must still succeed.
const VENDOR = [
  'https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@500;600;700&family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@400;500&display=swap',
  'https://unpkg.com/mqtt@5.10.1/dist/mqtt.min.js'
];

self.addEventListener('install', event => {
  event.waitUntil((async () => {
    const cache = await caches.open(VERSION);
    await cache.addAll(SHELL);
    await Promise.allSettled(VENDOR.map(u =>
      fetch(u, { mode: 'cors' }).then(r => r.ok && cache.put(u, r.clone())).catch(() => {})
    ));
    self.skipWaiting();
  })());
});

self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter(k => k !== VERSION).map(k => caches.delete(k)));
    await self.clients.claim();
  })());
});

function isModelAPI(url) {
  return /generativelanguage\.googleapis\.com|api\.anthropic\.com|broker\.emqx\.io/.test(url);
}

self.addEventListener('fetch', event => {
  const req = event.request;
  if (req.method !== 'GET') return;                 // never cache POSTs to the model APIs
  if (isModelAPI(req.url)) return;                  // always straight to the network

  event.respondWith((async () => {
    const cache = await caches.open(VERSION);
    const hit = await cache.match(req, { ignoreSearch: false });
    if (hit) {
      // refresh in the background so an updated build lands next launch
      fetch(req).then(r => { if (r && r.ok) cache.put(req, r.clone()); }).catch(() => {});
      return hit;
    }
    try {
      const res = await fetch(req);
      if (res && res.ok && (req.url.startsWith(self.registration.scope) ||
          /fonts\.(googleapis|gstatic)\.com|unpkg\.com/.test(req.url))) {
        cache.put(req, res.clone());
      }
      return res;
    } catch (e) {
      // Navigation offline → serve the app shell rather than the browser error page
      if (req.mode === 'navigate') {
        const shell = await cache.match('./index.html');
        if (shell) return shell;
      }
      throw e;
    }
  })());
});

self.addEventListener('message', e => {
  if (e.data === 'skipWaiting') self.skipWaiting();
});
