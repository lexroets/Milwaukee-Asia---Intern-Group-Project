# MILWAUKEE ONE-CHANNEL — installable demo app

Distributor channel operations console. Installs on an iPhone or Android phone
as a real app icon (fullscreen, no browser bars) and runs offline after first load.

## Files

| File | Purpose |
|---|---|
| `index.html` | The whole application |
| `manifest.webmanifest` | App name, icons, launch behaviour |
| `sw.js` | Service worker — offline caching |
| `logo.png`, `logo@2x.png` | Header wordmark |
| `icon-192/512`, `icon-maskable-512`, `apple-touch-icon`, `favicon-32` | App icons |

All files must stay in the **same folder**. The app will not install from a
`file://` path — it must be served over https.

---

## Step 1 — Put it online (2 minutes, free, no account)

1. Go to **app.netlify.com/drop**
2. Drag the **whole folder** onto the page
3. Copy the URL it gives you, e.g. `https://cheerful-otter-12ab.netlify.app`

That URL is now your app. Anyone you send it to can install it.

## Step 2 — Install on your iPhone

1. Open the URL **in Safari** (this does not work in Chrome on iOS)
2. Tap the **Share** button (square with an arrow, bottom centre)
3. Scroll down and tap **Add to Home Screen**
4. Tap **Add**

You now have a Milwaukee icon on your home screen. It opens fullscreen with no
address bar. On Android, Chrome shows an **Install** prompt instead.

## Step 3 — Before you present

1. Open the app → **Setup** (tab 07)
2. Paste a free Google AI Studio key → **Fetch models** → **Find one that works**
3. Tap **Pre-warm cache** — the scripted demo then costs zero API calls
4. Tap **Run self-test** under Diagnostics — expect 54/54
5. Force-quit and reopen so the demo starts from a clean state

If the venue wifi is doubtful, set Setup → mode → **Offline**. Every module still
works: translation of the scripted messages, order extraction, intent routing,
forecasting, churn. Only free-text a judge invents needs the live model.

---

## Live audience demo (the one to run on Friday)

1. **Laptop, on the projector**: Channel desk → Bridge → **Paired device** → **Connect bridge**
2. Click **Full screen** — a large QR fills the screen with the room code under it
3. **The audience scans it with their phone camera.** It opens the distributor view with
   the room code already filled in. They pick a platform, **type their own name**, tap Join —
   their name is what appears against the message on your screen.
   The platform they pick decides which site the message lands against
4. They type in any language — Chinese, Korean, Thai, whatever they like
5. Their message appears in your inbox translated, classified and routed, and the
   forecast and dispatch list update in front of them
6. Tap **Send reply** — your reply lands back on their phone in their own language

The QR only works if the page is published (step 1 of this README). Running from a
local file shows a warning in the panel.

If the venue blocks the message broker, switch to **Simulator** — seven recorded
messages across five platforms, no network needed.

## Navigating

- **Operations / Channels / Reports** in the red header open menus that jump to any module;
  Reports also scrolls straight to the relevant panel, and Operations has a shortcut
  straight to the dispatch lines that came from captured orders.
- **⌕** opens global search (or press Cmd/Ctrl-K). It searches sites, countries, products,
  knowledge base documents and inbox messages. Arrow keys to move, Enter to open.
- The **Device** button in the red header swaps between the operations desk and the
  distributor device view, at any screen size. On a phone it collapses to **⇄** and the
  modules move into the bottom tab bar.
- Connection state, model usage and the daily budget all live on **Setup** (tab 08) rather
  than in the header. If a live call fails, a badge appears on the Setup tab.

## Module 01 — Dashboard

Deliberately thin. Four numbers, one action list, and the accounts that are slipping.

**Messages to action · Orders captured today · Units waiting to ship · Accounts to watch.**
Every card is clickable and opens the module that owns it.

**What needs you now** ranks the day's work — urgent restocks, captured orders waiting
to ship, urgent dispatch lines, warranty claims, accounts falling away, and order lines
the SKU matcher could not place. Each row opens where it is resolved.

**Accounts to watch** lists only accounts with a churn risk of 30 or more. When everything
is trading normally it says so in one line rather than printing sixteen healthy rows.

## Module 02 → 03 — Capturing an order and shipping it

This is the spine of the demo.

1. A message lands in the **Channel desk** inbox and is translated, classified and turned
   into a structured purchase order.
2. Correct any quantity, drop any line you do not want, then press **Approve and capture**.
3. A purchase order reference is created, the message leaves the inbox, and the lines land
   on the **Dispatch list** against the site that sent them. A confirmation appears with a
   button straight to the dispatch tab, and the new lines are flagged **Just captured**.
4. Order lines the matcher cannot place — a work light, a ONE-KEY tag, a percussion drill,
   anything outside the four planned product lines — go to **Needs manual allocation** on the
   same tab. Nothing is dropped silently.

## Module 03 — Dispatch list

The operational output: what to ship, where, by when. Three sources merge into one list:

| Source | Where it comes from | Priority |
|---|---|---|
| Captured order | Approved on the channel desk | Urgent if the message carried time pressure, otherwise **Order**, ship in 2 days |
| Placed stock | A stocking offer accepted in module 05 | **Placed**, ship in 5 days |
| Cover top-up | A site below 30 days of forecast cover | Urgent below 18 days, otherwise **Top-up**, ship in 7 days |

Lines are grouped by country, most urgent country first, with per-country subtotals showing
how many units in that country came from a real order. Filter chips above the table narrow
by source or by country. Where an order and a top-up hit the same site and product they merge
into one line, and the units column shows the split.

Press **Dispatch** and stock at that site is replenished, so the line clears and cover improves.

Covers the 16 MILWAUKEE Asia sites across 11 countries:

| Country | Sites |
|---|---|
| Hong Kong SAR | Kwai Chung (regional HQ), Mong Kok (Heavy Duty Center) |
| China | Shanghai (commercial hub), Dongguan (engineering and manufacturing) |
| Thailand | Bangkok hub, Bangkok High Performance Center |
| Vietnam | Ho Chi Minh City, Hanoi |
| South Korea | Seoul |
| Singapore | Ubi Avenue |
| Malaysia | Selangor |
| Indonesia | Jakarta |
| Taiwan | Taichung |
| Philippines | Cebu City |
| Japan | Tokyo, Osaka |

The messaging platform a participant picks decides which site their message lands
against: WeChat → Shanghai, KakaoTalk → Seoul, LINE → Bangkok, WhatsApp → Singapore,
Zalo → Ho Chi Minh City.

If the venue blocks the message broker, use **Simulator** mode instead — it needs
no network and replays seven recorded messages across five platforms.

## Module 04 — Demand forecast

Pick a site, pick a product line — **10 product lines across the M18, M12, PACKOUT and
accessory ranges** — and the tab answers the four questions a planner actually asks:

- **How much will move?** 90-day forecast in units and trade value.
- **When do we run dry?** Cover is walked forward month by month against a *rising*
  forecast rather than divided by a flat average, so the date is honest.
- **What do I ship?** A quarter replenishment sized to clear the horizon and still close
  it with 60 days of cover, with the order-by date and the trade value.
- **Where does this site sit?** All 16 sites ranked on the selected line, with cover and
  position. Click a row to open it.

The chart carries 18 months shipped and 3 months forecast, split by a marked boundary, with
the confidence band shaded around the forecast. **Hover anywhere on it** and a crosshair
tracks the nearest month, drawing dashed lines to both axes with the value pinned on each —
the same read-off you get on a trading chart. The tooltip says whether that month is shipped
history or forecast, and for forecast months it gives the ± range. Touch works the same way
on a phone.

Cover, the run-dry date and the dispatch top-up all come from one calculation, so the
forecast tab and the dispatch list can never disagree about when a site runs short.

## Module 05 — Stocking offer

The commercial idea the project is built to prove, and the tab worth rehearsing before you
present it.

Asian distributors are working-capital constrained, so they stock what turns fastest and
MILWAUKEE loses shelf space it would otherwise win. This module offers an account
forecast-backed stock under a **90-day buy-back guarantee**: anything unsold at the end of
the window is repurchased at trade price. The distributor carries no inventory risk,
MILWAUKEE buys shelf presence, and in return the account shares its point-of-sale data
through the channel — which is what made the forecast accurate in the first place.

The tab walks the four steps in order: forecast the account, underwrite it, send the offer,
place and track it. Pick an account and product line at the top — the forecast module stays
in step — and the verdict box says in plain English whether it can be underwritten and what
the downside is in units and dollars.

- An offer is only generated at **78% model confidence or above**. Below that the box says
  how many points short the account is and both buttons are disabled.
- Exposure is capped at **400 units per account** and **1,500 across the programme**. Hitting
  either cap blocks the offer and says so.
- **Where the programme should go next** scores every site and product line against the gate
  and ranks them. Click a row to load it.
- **Accept and place the stock** books the exposure and puts the units on the dispatch list
  as placed stock.

## Module 06 — AI assistant

Answers counter and account questions grounded on the indexed documents, cites the ones
it used, and declines when nothing matches rather than inventing a spec.

The chat sits beside a panel listing what the assistant is good for and the six languages
it works in, so a first-time user can see what to ask before typing anything.

**It always replies in the language the question was asked in.** Korean question, Korean
answer; Thai, Vietnamese, Chinese, Japanese, Bahasa, English — same in, same out. The
source documents are in English and get translated on the way out. The answer is labelled
with the language it came back in, so you can show the rule working.

In offline mode it returns the retrieved source rather than a written answer, and the
framing around it is still in the asker's language.

## Module 07 — Knowledge base

43 indexed documents across 11 topics — company and brand, platforms, products, selling,
service, commercial, operations, markets, compliance, channel, and how this system itself
works. Each is labelled **Verified** (public, checkable), **Assumption** (a project
assumption, clearly flagged, which the assistant is told to describe as provisional) or
**Internal** (anything you paste in yourself).

Filter chips narrow the library by topic. **Retrieval test** shows exactly which documents a
question would pull and the score each one got, including the multilingual alias expansion —
useful if a judge asks how the grounding works.

The AI assistant answers only from these documents.

---

## Notes

- Demo data is synthetic and labelled as such in the UI.
- The Milwaukee wordmark is used for an internal-facing TTI presentation mockup.
- If you have installed an earlier build on your phone, force-quit and reopen it once
  after loading the new URL — the service worker version changed, so the old cached
  copy is replaced on the next launch.
- Voice notes play a generated waveform against a stored transcript; there is no
  speech recognition running. In production that is a Whisper/Google STT call
  ahead of the same pipeline.
- API keys are stored only in the phone's local browser storage, never in the files.
