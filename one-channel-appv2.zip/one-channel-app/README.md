# MILWAUKEE ONE-CHANNEL — installable demo app

Distributor channel operations console. Installs on an iPhone or Android phone
as a real app icon (fullscreen, no browser bars) and runs offline after first load.

## Files

| File | Purpose |
|---|---|
| `index.html` | The whole application |
| `manifest.webmanifest` | App name, icons, launch behaviour |
| `sw.js` | Service worker — offline caching |
| `logo.png`, `logo@2x.png` | Header wordmark |
| `icon-192/512`, `icon-maskable-512`, `apple-touch-icon`, `favicon-32` | App icons |

All files must stay in the **same folder**. The app will not install from a
`file://` path — it must be served over https.

---

## Step 1 — Put it online (2 minutes, free, no account)

1. Go to **app.netlify.com/drop**
2. Drag the **whole folder** onto the page
3. Copy the URL it gives you, e.g. `https://cheerful-otter-12ab.netlify.app`

That URL is now your app. Anyone you send it to can install it.

## Step 2 — Install on your iPhone

1. Open the URL **in Safari** (this does not work in Chrome on iOS)
2. Tap the **Share** button (square with an arrow, bottom centre)
3. Scroll down and tap **Add to Home Screen**
4. Tap **Add**

You now have a Milwaukee icon on your home screen. It opens fullscreen with no
address bar. On Android, Chrome shows an **Install** prompt instead.

## Step 3 — Before you present

1. Open the app → **Setup** (tab 07)
2. Paste a free Google AI Studio key → **Fetch models** → **Find one that works**
3. Tap **Pre-warm cache** — the scripted demo then costs zero API calls
4. Tap **Run self-test** under Diagnostics — expect 33/33
5. Force-quit and reopen so the demo starts from a clean state

If the venue wifi is doubtful, set Setup → mode → **Offline**. Every module still
works: translation of the scripted messages, order extraction, intent routing,
forecasting, churn. Only free-text a judge invents needs the live model.

---

## Live audience demo (the one to run on Friday)

1. **Laptop, on the projector**: Channel desk → Bridge → **Paired device** → **Connect bridge**
2. Click **Full screen** — a large QR fills the screen with the room code under it
3. **The audience scans it with their phone camera.** It opens the distributor view with
   the room code already filled in; they tap Join
4. They type in any language — Chinese, Korean, Thai, whatever they like
5. Their message appears in your inbox translated, classified and routed, and the
   forecast and dispatch list update in front of them
6. Tap **Send reply** — your reply lands back on their phone in their own language

The QR only works if the page is published (step 1 of this README). Running from a
local file shows a warning in the panel.

If the venue blocks the message broker, switch to **Simulator** — seven recorded
messages across five platforms, no network needed.

## Module 03 — Dispatch list

The operational output. One table: priority, account, city, tool, units, why, ship-by
date. It merges confirmed orders captured from the channel with stock-cover top-ups for
accounts about to run short. Press **Dispatch** on a line and stock at that account is
replenished, so the line clears and cover improves.

If the venue blocks the message broker, use **Simulator** mode instead — it needs
no network and replays seven recorded messages across five platforms.

---

## Notes

- Demo data is synthetic and labelled as such in the UI.
- The Milwaukee wordmark is used for an internal-facing TTI presentation mockup.
- Voice notes play a generated waveform against a stored transcript; there is no
  speech recognition running. In production that is a Whisper/Google STT call
  ahead of the same pipeline.
- API keys are stored only in the phone's local browser storage, never in the files.
